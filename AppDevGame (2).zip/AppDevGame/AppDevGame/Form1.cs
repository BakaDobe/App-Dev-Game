﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDevGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool left, right, jump;
        int force, speed, score;
        int frame = 1;


        void GameResult()
        {
            foreach (Control j in this.Controls)
            {
                if (j is PictureBox && j.Tag == "enemy")
                {
                    foreach (Control x in this.Controls)
                    {
                        if (x is PictureBox && x.Tag == "currency")
                        {
                            if (astronaut.Bounds.IntersectsWith(x.Bounds))
                            {
                                x.Dispose();
                                score++;
                                scoreLabel.Text = "Score: " + score;
                            }
                        }
                    }
                }
            }
            if (score == 6)
            {
                Level1 l1 = new Level1();
                l1.Show();
                score = 1;
            }
        }

        void Enemys()
        {
            if(en2.Left > 580)
            {
                speed -= 1;
            }
            if(en2.Left < 250)
            {
                speed = 1;
            }
            //en1.Left += speed;
            en2.Left += speed;
            //  en3.Left += speed;


        }

       

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            GameResult();
            Enemys();
            if (right == true)
            {
                if (astronaut.Left < 1140)
                {
                    astronaut.Left += 4;
                }
            }

            if (left == true)
            {
                if (astronaut.Left > 10)
                {
                    astronaut.Left -= 4;
                }
            }

            if (jump == true)
            {
                astronaut.Top -= 7;
                force = 3;
                
            }

            if(jump == false)
            {
                astronaut.Top += force;
            }

            foreach(Control x in this.Controls)
            {
                if(x is PictureBox && x.Tag=="base")
                {
                    if(astronaut.Bounds.IntersectsWith(x.Bounds) && !jump)
                    {
                        astronaut.Top = x.Top - astronaut.Height;
                        force = 0;
                    }

                    if (astronaut.Bounds.IntersectsWith(x.Bounds) && right || left)
                    {
                        force = 3;
                    }

                    if(astronaut.Bounds.IntersectsWith(x.Bounds)&& jump)
                    {
                        astronaut.Top = x.Top + astronaut.Height;
                        jump = false;
                    }

                    if(astronaut.Top + astronaut.Height < 50)
                    {
                        astronaut.Top += 3;
                    }
                }
            }
        }


        public void animate()
        {
            if (frame == 1)
            {
                astronaut.Image = Properties.Resources.RightRun;
            }
            else if(frame == 2)
            {
                astronaut.Image = Properties.Resources.LeftRun;
                frame = 1;
                return;
            }
            frame++;
        }

        private void Animation_Tick(object sender, EventArgs e)
        {
            if (right == true)
            {
                animate();
            }

            if (left == true)
            {
                animate();
            }

            if (jump == true)
            {
                astronaut.Image = Properties.Resources.Jump;
            }
        }


        private void IsKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D:
                    right = true;
                    break;
                case Keys.A:
                    left = true;
                    break;
                case Keys.Space:
                    jump = true;
                    break;
            }
        }

        private void IsKeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D:
                    right = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
                case Keys.A:
                    left = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
                case Keys.Space:
                    jump = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
            }
        }
    }
}
