﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDevGame
{
    public partial class Level1 : Form
    {
        bool left, right, jump;
        int force, speed;
        int frame = 1;
        public Level1()
        {
            InitializeComponent();
        }

        private void isKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D:
                    right = true;
                    break;
                case Keys.A:
                    left = true;
                    break;
                case Keys.Space:
                    jump = true;
                    break;
            }
        }

        private void isKeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D:
                    right = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
                case Keys.A:
                    left = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
                case Keys.Space:
                    jump = false;
                    astronaut.Image = Properties.Resources.Idle;
                    break;
            }
        }

        private void gameTimer2_Tick(object sender, EventArgs e)
        {
            if (right == true)
            {
                if (astronaut.Left < 1140)
                {
                    astronaut.Left += 4;
                }
            }

            if (left == true)
            {
                if (astronaut.Left > 10)
                {
                    astronaut.Left -= 4;
                }
            }

            if (jump == true)
            {
                astronaut.Top -= 7;
                force = 3;

            }

            if (jump == false)
            {
                astronaut.Top += force;
            }

            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag == "base")
                {
                    if (astronaut.Bounds.IntersectsWith(x.Bounds) && !jump)
                    {
                        astronaut.Top = x.Top - astronaut.Height;
                        force = 0;
                    }

                    if (astronaut.Bounds.IntersectsWith(x.Bounds) && right || left)
                    {
                        force = 3;
                    }

                    if (astronaut.Bounds.IntersectsWith(x.Bounds) && jump)
                    {
                        astronaut.Top = x.Top + astronaut.Height;
                        jump = false;
                    }

                    if (astronaut.Top + astronaut.Height < 50)
                    {
                        astronaut.Top += 3;
                    }
                }
            }
        }


        public void animate()
        {
            if (frame == 1)
            {
                astronaut.Image = Properties.Resources.RightRun;
            }
            else if (frame == 2)
            {
                astronaut.Image = Properties.Resources.LeftRun;
                frame = 1;
                return;
            }
            frame++;
        }

        private void animationTime_Tick(object sender, EventArgs e)
        {
            if (right == true)
            {
                animate();
            }

            if (left == true)
            {
                animate();
            }

            if (jump == true)
            {
                astronaut.Image = Properties.Resources.Jump;
            }
        }
    }
}
